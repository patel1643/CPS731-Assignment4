package com.example.recipes;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.provider.MediaStore;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

import static com.example.recipes.R.raw.loop;

public class SplashScreen extends AppCompatActivity {
    MediaPlayer sound;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sound = new MediaPlayer();
        sound = MediaPlayer.create(this, loop);
        sound.start();
        TimerTask timedTask = new TimerTask() {
            @Override
            public void run() {
//                sound.pause();
                finish();
                startActivity(new Intent(SplashScreen.this, ItemListActivity.class));
            }
        };

        Timer start = new Timer();
        start.schedule(timedTask, 5000);



    }
}
